<!-- Footer Type-1 -->
    <footer class="footer footer-type-1 bg-dark">
      <div class="container">
        <div class="footer-widgets top-bottom-dividers pb-mdm-20">
          <div class="row">


            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="widget footer-get-in-touch">
                <h5 class="widget-title uppercase">Kontak</h5>
                <address class="footer-address"><span>Alamat:</span> Jl.P.Diponegoro No.20</address>
                <p>No. HP: 085290359706</p>
                <p>Email: <a href="mailto: dipertan@grobogan.go.id"> dipertan@grobogan.go.id</a></p>
              </div>
              <div>
              <a class="whatlink" href="https://api.whatsapp.com/send?phone=+6285290359706&amp;text=Hi%20admin%20Tani%20Niaga,%20saya%20tertarik%20dengan%20Produk%20Anda.%20Bisa%20bantu%20saya%20untuk%20mendapatkan%20info%20lebih?" target="_blank" rel="noopener noreferrer"><img src="https://freeweb2app.com/wp-content/uploads/2020/01/whatsapp.png" alt="whatsapp"> Chat us</a>
            </div>
            </div> <!-- end stay in touch -->           
          </div>
        </div>    
      </div> <!-- end container -->

      <div class="bottom-footer bg-dark">
        <div class="container">
          <div class="row">
            <div class="col-sm-4 copyright sm-text-center">
              <span>
                &copy; 2020 by Media Computer
              </span>
            </div>
            <div> </div>


            <div class="col-sm-4 text-center">
              <div id="back-to-top">

                <a href="#top">
                  <i class="fa fa-angle-up"></i>
                </a>
              </div>
            </div>

           
          </div>
        </div>
      </div> <!-- end bottom footer -->
    </footer> <!-- end footer -->

