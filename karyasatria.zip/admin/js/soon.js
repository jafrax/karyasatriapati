$(document).on('ready', function(){

	'use strict';
	$('.countdown').downCount({
	    date: '01/26/2019 12:00:00',
	    offset: +10
	});
});